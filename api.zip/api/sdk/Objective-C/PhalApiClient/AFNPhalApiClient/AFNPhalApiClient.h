//
//  AFNPhalApiClient.h
//  PhalApiClientDemo
//
//  Created by Aevit on 15/10/18.
//  Copyright © 2015年 Aevit. All rights reserved.
//

#import "PhalApiClient.h"
#import "AFHTTPRequestOperationManager.h"

@interface AFNPhalApiClient : PhalApiClient

@end
