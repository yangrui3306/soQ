<?php
namespace App\Api;
use App\Domain\Userelation as Domain;
use PhalApi\Api;
use App\Common\MyStandard;

/**
 * 管理员类接口
 */
class Userelation extends Api{
	
	public function getRules(){
		return array(
			
		);
	}
}
