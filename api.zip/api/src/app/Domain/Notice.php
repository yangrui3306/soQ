<?php
namespace App\Domain;
use App\Model\Notice as Model;

class Notice {
	
}