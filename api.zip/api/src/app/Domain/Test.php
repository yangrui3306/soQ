<?php
namespace App\Domain;
use App\Model\Test as Model;

class Test {
	public function add($data){
		$model = new Model();
	}
}