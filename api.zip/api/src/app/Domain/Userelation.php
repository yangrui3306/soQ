<?php
namespace App\Domain;

use App\Model\Userelation as Model;

class Userelation {

}