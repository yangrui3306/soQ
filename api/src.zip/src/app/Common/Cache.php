<?php 
namespace App\Common;

// use PhalApi\Cache\RedisCache;
use PhalApi\Redis\Lite as RedisCache;

/**
 * 封装Redis
 */
class Cache extends RedisCache{

	/**
	 * 将数据加入缓存
	 * @param key    缓存key值，索引值
	 * @param value  缓存的数据
	 * @param expire 缓存的过期时间 + 加上随机时间，防止缓存雪崩问题单位s
	 */
	public function set($key, $value, $expire){
		// 过期时间加上随机时间1 ~ 10秒
		$randTime = rand(1000, 10000);
		$expire = $expire * 1000 + $randTime; // 实际过期时间
		$redis = new RedisCache();
		return $redis -> set($key, $value, $expire);
	}

	/**
	 * 获取缓存数据
	 * @param key  缓存key值
	 */
	public function get($key){
		$redis = new RedisCache();
		if($this -> checkKey($key) == false){
			return false;
		}
		$data = $redis -> get($key);
		if(!$data){
			return false;
		}
		return $data;
	}

	/**
	 * 删除缓存数据
	 * @param key 缓存key值
	 */
	public function delete($key){
		$redis = new RedisCache();
		if($this -> checkKey($key) == false){
			return false;
		}
		$res = $redis -> delete($key);
		if(!$res){
			return false;
		}
		return true;
	}

	/**
	 * 过滤不合法key,预防缓存穿透
	 * @param key 缓存key值
	 */
	private function checkKey($key){
		// 如果key值为id时则不允许key值为0或负数
		if(is_int($key) == true && $key <= 0){
			return false;
		}
		return true;
	}
}